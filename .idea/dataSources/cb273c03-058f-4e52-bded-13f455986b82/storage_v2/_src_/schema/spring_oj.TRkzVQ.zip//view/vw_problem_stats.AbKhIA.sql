create definer = root@`%` view vw_problem_stats as
select `p`.`id`                                                                                                       AS `problem_id`,
       count(`s`.`id`)                                                                                                AS `submission_count`,
       sum((case when (`s`.`verdict` = 'AC') then 1 else 0 end))                                                      AS `solved_count`,
       round((case
                  when (count(`s`.`id`) = 0) then NULL
                  else ((sum((case when (`s`.`verdict` = 'AC') then 1 else 0 end)) / count(`s`.`id`)) * 100) end),
             2)                                                                                                       AS `acceptance_rate`,
       max(`s`.`created_at`)                                                                                          AS `last_submission_at`
from (`spring_oj`.`problems` `p` left join `spring_oj`.`submissions` `s` on ((`s`.`problem_id` = `p`.`id`)))
group by `p`.`id`;

-- comment on column vw_problem_stats.problem_id not supported: 题目ID

-- comment on column vw_problem_stats.last_submission_at not supported: 提交时间

