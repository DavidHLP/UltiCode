create definer = root@`%` view vw_user_problem_best as
select `s`.`user_id`                                                               AS `user_id`,
       `s`.`problem_id`                                                            AS `problem_id`,
       min((case when (`s`.`verdict` = 'AC') then `s`.`created_at` else NULL end)) AS `first_ac_time`,
       max(`s`.`score`)                                                            AS `best_score`
from `spring_oj`.`submissions` `s`
group by `s`.`user_id`, `s`.`problem_id`;

-- comment on column vw_user_problem_best.user_id not supported: 提交用户ID

-- comment on column vw_user_problem_best.problem_id not supported: 题目ID

-- comment on column vw_user_problem_best.best_score not supported: 得分

